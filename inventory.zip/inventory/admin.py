from django.contrib import admin
from unfold.admin import ModelAdmin

from inventory.models import (
    InventoryItem,
    InventoryMovement,
    Warehouse,
    StockLocation,
    InventoryCategory,
)


# -------------------------
# Warehouse + StockLocation
# -------------------------
class StockLocationInline(admin.TabularInline):
    model = StockLocation
    extra = 0
    fields = ("name", "code", "is_active")
    show_change_link = True


@admin.register(Warehouse)
class WarehouseAdmin(ModelAdmin):
    list_display = ("id", "name", "code", "is_active")
    search_fields = ("name", "code")
    inlines = (StockLocationInline,)


@admin.register(StockLocation)
class StockLocationAdmin(ModelAdmin):
    list_display = ("id", "warehouse", "location_type", "name", "code", "is_active", "source_repr")
    list_filter = ("warehouse", "is_active", "location_type")
    search_fields = ("name", "code", "warehouse__name", "content_type__app_label")  # helps the admin search
    readonly_fields = ("source_repr",)

    # Show content_type and object_id in the form so admin can pick the linked object.
    # raw_id_fields is useful for content_type lookup; object_id remains a plain input.
    raw_id_fields = ("content_type",)

    fieldsets = (
        (None, {
            "fields": ("warehouse", "location_type", "name", "code", "is_active")
        }),
        ("Link to external object (optional)", {
            "fields": ("content_type", "object_id", "source_repr"),
            "description": "Link this location to any object (material, warehouse master, etc.). "
                           "If linked, name/code will be auto-filled when possible.",
        }),
    )

    def source_repr(self, obj):
        return str(obj.source_object) if obj and obj.source_object else "-"
    source_repr.short_description = "Linked source"



# -------------------------
# InventoryCategory
# -------------------------
@admin.register(InventoryCategory)
class InventoryCategoryAdmin(ModelAdmin):
    list_display = ("id", "name")
    search_fields = ("name",)


# -------------------------
# InventoryItem admin
# -------------------------
# bulk actions to change status quickly
@admin.action(description="Mark selected as ACTIVE")
def mark_active(modeladmin, request, queryset):
    queryset.update(status="ACTIVE")


@admin.action(description="Mark selected as REQUESTED")
def mark_requested(modeladmin, request, queryset):
    queryset.update(status="REQUESTED")


@admin.action(description="Mark selected as RESERVED")
def mark_reserved(modeladmin, request, queryset):
    queryset.update(status="RESERVED")


@admin.register(InventoryItem)
class InventoryItemAdmin(ModelAdmin):
    list_display = ("id", "status", "tag", "category", "location", "quantity", "created_at")
    list_display_links = ("id",)
    list_filter = ("status", "category", "location", "content_type")
    search_fields = ("id", "tag", "object_id")
    ordering = ("-created_at",)
    list_editable = ("status",)

    # fast selection + green "+" to add new entries inline
    autocomplete_fields = ("category", "location")

    # content_type can be long — use raw id widget
    raw_id_fields = ("content_type",)

    actions = (mark_active, mark_requested, mark_reserved)


# -------------------------
# InventoryMovement admin
# -------------------------
@admin.register(InventoryMovement)
class InventoryMovementAdmin(ModelAdmin):
    list_display = ("timestamp", "movement_type", "quantity_change", "location", "user")
    list_filter = ("movement_type", "location")
    search_fields = ("location", "note")
    ordering = ("-timestamp",)
