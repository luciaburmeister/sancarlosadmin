from django.db import models
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType

from timestamps.models import Timestampable

class InventoryStatus(models.TextChoices):
    ACTIVE = "ACTIVE", _("Active")
    REQUESTED = "REQUESTED", _("Requested")
    RESERVED = "RESERVED", _("Reserved")


class InventoryCategory(Timestampable):
    name = models.CharField(max_length=120, unique=True)

    class Meta:
        verbose_name = "Inventory Category"
        verbose_name_plural = "Inventory Categories"

    def __str__(self):
        return self.name


class Warehouse(Timestampable):
    name = models.CharField(max_length=120)
    code = models.CharField(max_length=30, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Warehouse"
        verbose_name_plural = "Warehouses"

    def __str__(self):
        return self.code or self.name


class LocationType(models.TextChoices):
    WAREHOUSE = "WAREHOUSE", _("Warehouse")
    BIN = "BIN", _("Bin/Slot")
    OTHER = "OTHER", _("Other")


class StockLocation(Timestampable):
    """
    Structured locations inside a warehouse or standalone.
    - Keeps optional FK to Warehouse for backwards compatibility (warehouse field).
    - Also accepts a generic link (content_type/object_id) to any other module's object.
    - If `source_object` is set and `name` or `code` are blank, they will be
      populated from the source_object (if that object exposes .name and/or .code).
    """

    warehouse = models.ForeignKey(
        "inventory.Warehouse",
        on_delete=models.PROTECT,
        related_name="locations",
        null=True,
        blank=True,
        help_text="(Legacy) parent warehouse; optional if you use a generic source.",
    )

    # NEW: explicit type so you can pick what kind of loc this is
    location_type = models.CharField(max_length=20, choices=LocationType.choices, default=LocationType.BIN, db_index=True)

    # Allow linking to an arbitrary source model (Material, Warehouse master, etc.)
    content_type = models.ForeignKey(
        ContentType,
        on_delete=models.PROTECT,
        related_name="stock_locations",
        null=True,
        blank=True,
    )
    object_id = models.PositiveBigIntegerField(null=True, blank=True)
    source_object = GenericForeignKey("content_type", "object_id")

    name = models.CharField(max_length=120)
    code = models.CharField(max_length=40, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["warehouse", "code"],
                name="uniq_stock_location_warehouse_code",
            )
        ]
        verbose_name = "Stock Location"
        verbose_name_plural = "Stock Locations"

    def __str__(self):
        # Prefer the explicit code/name; if linked to a source and that has a display, use it
        if self.source_object:
            # source_object may be any model — use its __str__ if available
            return f"{self.source_object} ({self.code or self.name})"
        return f"{self.warehouse or ''} / {self.code or self.name}"

    def save(self, *args, **kwargs):
        """
        If this StockLocation references a source_object (Generic FK), and the
        current name/code are blank, attempt to populate them from the source.
        This is the 'auto-register the code etc.' behavior you requested.
        """
        src = self.source_object
        # Only attempt when a source is present
        if src is not None:
            # Try common attribute names; be forgiving.
            try:
                # if name blank, try common attributes
                if (not self.name or self.name.strip() == ""):
                    for attr in ("name", "title", "display_name"):
                        if hasattr(src, attr):
                            v = getattr(src, attr)
                            if v:
                                self.name = str(v)
                                break
                # if code blank, try common attributes
                if (not self.code or self.code.strip() == ""):
                    for attr in ("code", "sku", "reference", "slug"):
                        if hasattr(src, attr):
                            v = getattr(src, attr)
                            if v:
                                self.code = str(v)
                                break
            except Exception:
                # never raise on save auto-fill — fail silently so admin flow isn't blocked
                pass

        super().save(*args, **kwargs)


class InventoryItem(Timestampable):
    # --- existing GFK fields (unchanged)
    content_type = models.ForeignKey(
        ContentType,
        on_delete=models.PROTECT,
        related_name="inventory_items",
        null=True,
        blank=True,
    )
    object_id = models.PositiveBigIntegerField(null=True, blank=True)
    source_object = GenericForeignKey("content_type", "object_id")

    status = models.CharField(
    max_length=20,
    choices=InventoryStatus.choices,
    default="ACTIVE",
    db_index=True,
)

    tag = models.CharField(
        max_length=120,
        blank=True,
        db_index=True,
        help_text="Optional name/tag to identify this inventory record (ERP-style).",
    )

    category = models.ForeignKey(
        InventoryCategory,
        null=True,
        blank=True,
        on_delete=models.PROTECT,
        related_name="inventory_items",
    )

    # --- existing fields (unchanged)
    quantity = models.IntegerField(default=0)
    updated_at = models.DateTimeField(auto_now=True)

    location = models.ForeignKey(
        StockLocation,
        null=True,
        blank=True,
        on_delete=models.PROTECT,
        related_name="inventory_items",
        help_text="Optional structured location.",
    )


class MovementType(models.TextChoices):
    IN = "IN", _("Stock In")
    OUT = "OUT", _("Stock Out")
    ADJUST = "ADJUST", _("Adjustment")
    TRANSFER = "TRANSFER", _("Transfer")  


class InventoryMovement(Timestampable):
    """
    A stock movement (entry, exit, adjustment, transfer).
    quantity_change: positive = stock in, negative = stock out.
    """

    content_type = models.ForeignKey(
        ContentType,
        on_delete=models.PROTECT,
        related_name="inventory_movements",
        null=True,
        blank=True,
    )
    object_id = models.PositiveBigIntegerField(null=True, blank=True)
    source_object = GenericForeignKey("content_type", "object_id")

    movement_type = models.CharField(max_length=10, choices=MovementType.choices)

    quantity_change = models.IntegerField(
    help_text="Positive for stock-in, negative for stock-out."
)

    timestamp = models.DateTimeField(default=timezone.now)

    user = models.ForeignKey(
        "auth.User",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        help_text="User who performed the movement.",
    )

    location = models.ForeignKey(
        StockLocation,
        null=True,
        blank=True,
        on_delete=models.PROTECT,
        related_name="inventory_movements",
        help_text="Optional structured location.",
    )

    note = models.TextField(blank=True)

    class Meta:
        ordering = ["-timestamp"]
        indexes = [
            models.Index(fields=["timestamp"], name="idx_invmov_timestamp"),
            models.Index(fields=["movement_type"], name="idx_invmov_type"),
            models.Index(fields=["content_type", "object_id"], name="idx_invmov_source"),
            models.Index(fields=["location"], name="idx_invmov_location"),
        ]
        verbose_name = "Inventory Movement"
        verbose_name_plural = "Inventory Movements"

    def __str__(self):
        obj = self.source_object
        obj_label = str(obj) if obj else "—"
        return f"{self.timestamp:%Y-%m-%d %H:%M} — {obj_label} — {self.quantity_change:+f}"
